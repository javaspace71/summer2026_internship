/*
  ================================================================================
  PROJECT: Serial-Controlled Interactive Terminal Interface
  AUTHOR:         G Venkat
  ORGANIZATION:   byteSmart
  WEBSITE:        https://bytesmart.info
  DATE:           July 2026
  VERSION:        1.0.0
  
  COPYRIGHT & LICENSE:
  Copyright (c) 2026 G Venkat. All rights reserved.

  
  TERMS OF USE & COMMERCIAL RESTRICTIONS:
  1. Personal & Educational Use: Free to use, modify, and distribute for 
     non-commercial purposes, provided this complete notice remains intact.
  2. Commercial Use & Extensions: ANY commercial use, sale, or derivative 
     extension of this software is strictly prohibited without prior written 
     permission. For commercial licensing inquiries, please contact the 
     Author and Organization at the email address listed above.
     
  This software is provided "as is", without warranty of any kind.
  ================================================================================
  
  WHAT THIS SIGNATURE PROGRAM DOES:
  This program establishes a two-way interactive communication line between the 
  user and the Arduino hardware. It listens closely to characters typed into the 
  Serial Monitor. Entering 'H' applies power to the onboard indicator, entering 
  'L' terminates power, and any unsupported characters trigger an automated 
  error safety response to guide the user.
*/

// --- STEP 1: HARDWARE INITIALIZATION ---

// We assign the built-in system LED pin to a clear, meaningful variable name.
const int TARGET_LED = LED_BUILTIN;


// --- STEP 2: THE SETUP FUNCTION (Runs Exactly ONCE) ---

void setup() {
  
  // Open the serial data pipeline at 115200 baud. 
  // (Upgraded from 9600 for faster text rendering and modern compatibility).
  Serial.begin(115200);
  
  // This 'while' loop halts the hardware completely until the user opens 
  // the Serial Monitor window on their computer screen.
  while (!Serial) {
    ; // Do nothing, just pause execution safely
  }

  // Configure our designated LED pin as an OUTPUT so it can push voltage
  pinMode(TARGET_LED, OUTPUT);

  // Print a friendly, clear, professional user interface layout to the screen
  Serial.println(F("\n========================================"));
  Serial.println(F("     ARDUINO SERIAL HARDWARE CONTROL    "));
  Serial.println(F("========================================"));
  Serial.println(F(" Commands Recognized:"));
  Serial.println(F("   [H] or [h] -> Illuminate Target LED"));
  Serial.println(F("   [L] or [l] -> Extinguish Target LED"));
  Serial.println(F("========================================"));
  Serial.print(F("Enter Command: "));
}


// --- STEP 3: THE LOOP FUNCTION (Runs Forever) ---

void loop() {
  
  // 'Serial.available()' checks the internal memory buffer of the Arduino 
  // to see if any data bytes have traveled down the USB cable from the computer.
  // If the number is greater than 0, it means the user typed something and hit send!
  if (Serial.available() > 0) {
    
    // 'Serial.read()' grabs the oldest single character waiting in that buffer 
    // and copies it directly into a storage variable named 'command'.
    char command = Serial.read();
    
    // --- ADVANCED FILTERING TRICK ---
    // When you press 'Send' in the Serial Monitor, it sometimes attaches invisible 
    // formatting characters like Newlines ('\n') or Carriage Returns ('\r'). 
    // This 'if' statement detects them and silently skips over them so they don't 
    // break our code logic.
    if (command == '\n' || command == '\r') {
      return; // "return" instantly exits the loop() function and restarts it from the top
    }

    // --- EVALUATING USER INPUT ---

    // The '||' operator represents a logical "OR". 
    // This reads: "If the typed character matches capital H OR lowercase h..."
    if (command == 'H' || command == 'h') {
      
      // Send electrical voltage out through the pin to turn the light ON
      digitalWrite(TARGET_LED, HIGH);
      
      // Print confirmation status directly back to the user
      Serial.println(command); // Echo the letter they typed next to "Enter Command:"
      Serial.println(F("[ACTION] Target hardware activated -> LED is now ON."));
      Serial.println(F("----------------------------------------"));
      Serial.print(F("Enter Command: "));
    } 
    
    // This reads: "Otherwise, if the typed character matches capital L OR lowercase l..."
    else if (command == 'L' || command == 'l') {
      
      // Cut off the electrical voltage to ground, forcing the light OFF
      digitalWrite(TARGET_LED, LOW);
      
      Serial.println(command); // Echo the letter they typed
      Serial.println(F("[ACTION] Target hardware deactivated -> LED is now OFF."));
      Serial.println(F("----------------------------------------"));
      Serial.print(F("Enter Command: "));
    } 
    
    // The final 'else' statement handles the "Safety Catch-All".
    // If the user types anything else (like 'X', '5', or a question mark), this code runs.
    else {
      Serial.println(command); // Echo the invalid letter they typed
      Serial.print(F("[WARNING] Unknown command '"));
      Serial.print(command);
      Serial.println(F("' rejected. Please use 'H' or 'L'."));
      Serial.println(F("----------------------------------------"));
      Serial.print(F("Enter Command: "));
    }
  }
}