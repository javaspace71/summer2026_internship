/*
  ================================================================================
  PROJECT: Hardware-Driven Quantum Matrix Terminal Simulation
  AUTHOR:         G Venkat
  ORGANIZATION:   byteSmart
  WEBSITE:        https://bytesmart.info
  DATE:           July 2026
  VERSION:        1.0.0
  
  COPYRIGHT & LICENSE:
  Copyright (c) 2026 G Venkat. All rights reserved.
  
  TERMS OF USE & COMMERCIAL RESTRICTIONS:
  1. Personal & Educational Use: Free to use, modify, and distribute for 
     non-commercial purposes, provided this complete notice remains intact.
  2. Commercial Use & Extensions: ANY commercial use, sale, or derivative 
     extension of this software is strictly prohibited without prior written 
     permission. For commercial licensing inquiries, please contact the 
     Author and Organization at the email address listed above.
     
  This software is provided "as is", without warranty of any kind.
  ================================================================================
  
  WHAT THIS SIGNATURE PROGRAM DOES:
  This program leverages the onboard True Random Number Generator (TRNG) hardware 
  built into modern chips (like the Renesas RA4M1 on the Arduino UNO R4). Instead of 
  using predictable math equations for "pseudo-random" numbers, it reads actual 
  quantum atmospheric/thermal noise to generate truly unpredictable values. It uses 
  these values alongside ANSI terminal escape codes to render a live, retro 
  "Matrix Digital Rain" animation directly inside your Serial Monitor.
*/

// --- STEP 1: INCLUDE LIBRARIES ---
// The trng.h library wakes up the dedicated mathematical entropy engine inside 
// the main microcontroller chip to generate true hardware random numbers.
#include <trng.h> 

// --- STEP 2: GLOBAL UTILITY CONFIGURATIONS ---
const unsigned long SERIAL_SPEED = 115200; // Ultra-fast baud rate for fluid animations
const int FRAME_DELAY_MS = 15;             // Delay time to smooth out screen updates


// --- STEP 3: THE SETUP FUNCTION (Runs Exactly ONCE) ---

void setup() {
  
  // Establish high-speed data connection back to your computer console
  Serial.begin(SERIAL_SPEED); 
  
  // Pause code execution until the user physically opens the Serial Monitor window
  while (!Serial) {
    ; // Do nothing, wait for terminal connection
  }
  
  // Initialize and boot up the internal TRNG hardware engine modules
  TRNG.begin(); 
  
  // --- EXPLAINING THE TERMINAL MAGIC: ANSI ESCAPE SEQUENCES ---
  // The strange symbols below ("\e[...") are ANSI escape codes. They are universal 
  // instructions sent to terminal monitors telling them to change colors or look.
  //   \e[2J  -> Tells the monitor to completely wipe the screen clear
  //   \e[H   -> Moves the typing cursor back up to the absolute top-left corner
  //   \e[40m -> Sets the text background color to solid Black
  //   \e[32m -> Sets the foreground typing text color to bright Green
  Serial.print("\e[2J\e[H\e[40m\e[32m");
  
  Serial.println(F("--- Quantum Matrix Rain Initialized ---"));
}


// --- STEP 4: THE LOOP FUNCTION (Runs Forever) ---

void loop() {
  
  // Create an array container made of 4 slots to hold a huge 128-bit chunk of data.
  // 'uint32_t' means "Unsigned Integer 32-bit" (positive whole numbers up to ~4.2 billion).
  uint32_t randomBuffer[4]; 
  
  // Command the TRNG chip to grab 128 bits of pure hardware noise and dump it into our array
  TRNG.read128(randomBuffer); 
  
  // Isolate just the first 32-bit slot out of our array to use for our math logic
  uint32_t randomValue = randomBuffer[0]; 
  
  // --- GENERATING GLYPH DENSITY ---
  // We use the Modulo operator '%' which calculates the remainder of a division.
  // This line reads: "If our random number can be divided by 5 with a remainder of 0..."
  // This sets up a 1-in-5 (20%) chance that any given screen slot gets a character.
  if ((randomValue % 5) == 0) {
    
    // Convert the massive random number into a printable keyboard character.
    // Standard ASCII symbols live between codes 33 and 126. Modulo 93 sets boundaries, 
    // and adding 33 ensures we map perfectly to visible letters, numbers, and symbols.
    char matrixChar = (randomValue % 93) + 33; 
    
    // Explicitly re-enforce green text on black background for each character printed
    Serial.print("\e[40m\e[32m");
    Serial.print(matrixChar);
    
  } else {
    
    // If the 1-in-5 chance failed (80% of the time), print a empty space instead.
    // This creates the gaps and emptiness needed to make the code look like falling streams.
    Serial.print("\e[40m "); 
  }
  
  // --- TRIGGERING NEW LINES (FALLING EFFECT) ---
  // This sets up a 1-in-40 chance every loop cycle to hit the enter key.
  // This pushes down lines randomly, preventing standard uniform text blocks.
  if ((randomValue % 40) == 0) {
    Serial.println();
  }
  
  // Pause the execution briefly to let the human eye process the animation frames
  delay(FRAME_DELAY_MS); 
}