/*
  ================================================================================
  PROJECT: HID Keyboard Emulation & Automated Text Utility
  AUTHOR:         G Venkat
  ORGANIZATION:   byteSmart
  WEBSITE:        https://bytesmart.info
  DATE:           July 2026
  VERSION:        1.0.0
  
  COPYRIGHT & LICENSE:
  Copyright (c) 2026 G Venkat. All rights reserved.
  
  TERMS OF USE & COMMERCIAL RESTRICTIONS:
  1. Personal & Educational Use: Free to use, modify, and distribute for 
     non-commercial purposes, provided this complete notice remains intact.
  2. Commercial Use & Extensions: ANY commercial use, sale, or derivative 
     extension of this software is strictly prohibited without prior written 
     permission. For commercial licensing inquiries, please contact the 
     Author and Organization at the email address listed above.
     
  This software is provided "as is", without warranty of any kind.
  ================================================================================
  
  WHAT THIS SIGNATURE PROGRAM DOES:
  This program configures the Arduino to act as a native HID (Human Interface Device) 
  Keyboard. When plugged into a computer, the computer thinks a real physical 
  keyboard has been attached. The program counts down a 5-second safety safety window, 
  and then automatically types out a custom text string and presses 'Enter' 
  completely on its own.
*/

// --- STEP 1: INCLUDE LIBRARIES ---
// The Keyboard library allows boards with native USB capabilities (like the 
// Renesas processor on the UNO R4) to emulate a USB keyboard.
#include "Keyboard.h"

// --- STEP 2: GLOBAL CONFIGURATIONS ---
// Setting our safety delay timer in milliseconds (5000ms = 5 seconds)
const unsigned long INITIAL_DELAY = 5000;


// --- STEP 3: THE SETUP FUNCTION (Runs Exactly ONCE) ---

void setup() {
  
  // Initialize the Keyboard emulation layer. This tells the computer's operating 
  // system to recognize the Arduino as an input device.
  Keyboard.begin();
  
  // --- CRITICAL SAFETY DELAY ---
  // When programming an automatic keyboard tool, always include a long delay 
  // at the start. This gives the human operator 5 seconds to open a text editor 
  // (like Notepad or TextEdit) and click inside it before the typing begins!
  delay(INITIAL_DELAY); 

  // 'Keyboard.print()' transmits characters down the USB wire exactly as if 
  // you were typing them on a physical keyboard button by button.
  Keyboard.print("Hello from the Arduino R4 Minima processor! ");
  
  // 'Keyboard.press()' simulates physically holding a specific key down.
  // 'KEY_RETURN' is the internal programming code for the 'Enter' key.
  Keyboard.press(KEY_RETURN); 
  
  // SAFETY CATCH: Whenever you command a key to press down, you MUST release it!
  // 'Keyboard.releaseAll()' lets go of all virtual keys currently held down.
  // If you forget this line, the computer will act as if the 'Enter' key is stuck down forever.
  Keyboard.releaseAll();
  
  // End the keyboard session cleanly to let the operating system know the script is done
  Keyboard.end();
}


// --- STEP 4: THE LOOP FUNCTION (Runs Forever) ---

void loop() {
  
  // We leave this function completely empty. 
  // Since the loop runs forever, leaving it blank ensures our automated typing routine 
  // only triggers exactly ONCE during setup, rather than typing in an infinite loop!
}