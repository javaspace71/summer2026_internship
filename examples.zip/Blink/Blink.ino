/*
  ================================================================================
  PROJECT: Custom Heartbeat LED Pulse Indicator
  AUTHOR:         G Venkat
  ORGANIZATION:   byteSmart
  WEBSITE:        https://bytesmart.info
  DATE:           July 2026
  VERSION:        1.0.0
  
  COPYRIGHT & LICENSE:
  Copyright (c) 2026 G Venkat. All rights reserved.
  
  TERMS OF USE & COMMERCIAL RESTRICTIONS:
  1. Personal & Educational Use: Free to use, modify, and distribute for 
     non-commercial purposes, provided this complete notice remains intact.
  2. Commercial Use & Extensions: ANY commercial use, sale, or derivative 
     extension of this software is strictly prohibited without prior written 
     permission. For commercial licensing inquiries, please contact the 
     Author and Organization at the email address listed above.
     
  This software is provided "as is", without warranty of any kind.
  ================================================================================
  
  WHAT THIS SIGNATURE PROGRAM DOES:
  Instead of a standard 1-second blink, this modified program commands the 
  onboard LED to mimic a beating heart (two rapid pulses followed by a rest period). 
  It also transmits the current operational status of the LED over the USB cable 
  back to your computer's Serial Monitor in real-time.
*/

// --- STEP 1: VARIABLES & CONSTANTS (Our Custom Settings) ---

// 'const int' means "Constant Integer". This is a variable container for a whole 
// number that will NEVER change while the program is running.
// We are giving the physical onboard LED pin (Pin 13 on most Unos) a custom nickname: 'STATUS_LED'
const int STATUS_LED = LED_BUILTIN; 

// Here we define our custom timing parameters in milliseconds (1000ms = 1 second)
const int PULSE_DURATION = 150;  // How long the LED stays on during a heartbeat pulse
const int SHORT_PAUSE    = 200;  // The quick rest between the two beats of a heartbeat
const int LONG_PAUSE     = 1200; // The longer rest period between full heartbeats


// --- STEP 2: THE SETUP FUNCTION (Runs Exactly ONCE) ---

void setup() {
  
  // Initialize Serial communication over the USB cable at a speed of 115200 baud.
  // This turns on the text communication line between the Arduino and your computer.
  Serial.begin(115200);
  
  // This loop pauses the Arduino until you physically click and open the Serial Monitor.
  // This stops the program from printing status messages into a closed window!
  while (!Serial) {
    ; // Do nothing, just wait for the user to open the monitor console
  }

  // Print a professional opening banner to show your custom program has started
  Serial.println(F("\n========================================"));
  Serial.println(F(" Custom Heartbeat Monitor Initialized    "));
  Serial.println(F("========================================"));

  // The 'pinMode' command configures a specific pin's electrical behavior.
  // We tell the Arduino that our STATUS_LED pin must act as an OUTPUT. This means 
  // the pin pushes electricity OUT of the board to power the LED, rather than listening.
  pinMode(STATUS_LED, OUTPUT);
  
  Serial.println(F("-> Hardware Configuration: LED Pin set to OUTPUT."));
  Serial.println(F("-> Starting Pulse Sequence...\n"));
}


// --- STEP 3: THE LOOP FUNCTION (Runs Forever) ---

void loop() {
  
  // ------------------------------------------------------------------
  // FIRST BEAT OF THE HEART
  // ------------------------------------------------------------------
  
  // 'digitalWrite' tells a pin to turn its electricity completely ON or completely OFF.
  // 'HIGH' sends full voltage (5V or 3.3V) to the pin, forcing the LED to light up.
  digitalWrite(STATUS_LED, HIGH);  
  Serial.println(F("[STATUS] LED State: HIGH (First Beat)"));
  
  // Hold this state for our custom pulse duration time
  delay(PULSE_DURATION);           

  // 'LOW' drops the voltage on the pin down to 0V, turning the LED completely off.
  digitalWrite(STATUS_LED, LOW);   
  
  // Rest briefly before firing the second beat
  delay(SHORT_PAUSE);              


  // ------------------------------------------------------------------
  // SECOND BEAT OF THE HEART
  // ------------------------------------------------------------------
  
  // Turn the LED right back on for the second half of the double-pulse
  digitalWrite(STATUS_LED, HIGH);  
  Serial.println(F("[STATUS] LED State: HIGH (Second Beat)"));
  
  delay(PULSE_DURATION);           

  // Turn the LED off again
  digitalWrite(STATUS_LED, LOW);   
  Serial.println(F("[STATUS] LED State: LOW  (Resting Period)"));
  Serial.println(F("----------------------------------------"));
  
  // Hold the LED in the OFF state for a longer pause before restarting the entire loop
  delay(LONG_PAUSE);              
}