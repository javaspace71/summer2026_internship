/*
  ================================================================================
  PROJECT: Automated Morse Code SOS Distress Beacon
  AUTHOR:         G Venkat
  ORGANIZATION:   byteSmart
  WEBSITE:        https://bytesmart.info
  DATE:           July 2026
  VERSION:        1.0.0
  
  COPYRIGHT & LICENSE:
  Copyright (c) 2026 G Venkat. All rights reserved.
  
  TERMS OF USE & COMMERCIAL RESTRICTIONS:
  1. Personal & Educational Use: Free to use, modify, and distribute for 
     non-commercial purposes, provided this complete notice remains intact.
  2. Commercial Use & Extensions: ANY commercial use, sale, or derivative 
     extension of this software is strictly prohibited without prior written 
     permission. For commercial licensing inquiries, please contact the 
     Author and Organization at the email address listed above.
     
  This software is provided "as is", without warranty of any kind.
  ================================================================================
  
  WHAT THIS SIGNATURE PROGRAM DOES:
  This program drives an automated visual signaling beacon using international 
  Morse code. It coordinates precise timing cycles to blink the universal emergency 
  "SOS" sequence (... --- ...) on the board's onboard LED indicator. It breaks the 
  logic down into a reusable function, making the software modular and scalable.
*/

// --- STEP 1: GLOBAL CONFIGURATIONS & CONSTANTS ---

// Give the built-in system LED pin a clear, human-readable nickname
const int BEACON_LED = LED_BUILTIN;

// Establish standardized Morse code timing rules (in milliseconds)
const int SHORT_BLINK_MS = 200;  // Duration for a Morse code "dot" (.)
const int LONG_BLINK_MS  = 600;  // Duration for a Morse code "dash" (-)
const int INNER_GAP_MS   = 200;  // Rest time between individual flashes of a single letter
const int LETTER_GAP_MS  = 200;  // Rest time between full letters (S to O, O to S)
const int CYCLE_DELAY_MS = 3000; // Reset rest time before repeating the full SOS signal


// --- STEP 2: THE SETUP FUNCTION (Runs Exactly ONCE) ---

void setup() {
  
  // Initialize Serial communication at 115200 baud for status tracking
  Serial.begin(115200);
  
  // Configure our designated beacon pin as an OUTPUT so it can push voltage to the LED
  pinMode(BEACON_LED, OUTPUT);
  
  // Print an opening status monitor banner
  Serial.println(F("\n========================================"));
  Serial.println(F("    MORSE CODE EMERGENCY BEACON ACTIVE  "));
  Serial.println(F("========================================"));
  Serial.println(F("-> Visual Matrix Configured: Pin set to OUTPUT."));
  Serial.println(F("-> Broadcasting Sequence: [ . . .  --- --- ---  . . . ]\n"));
}


// --- STEP 3: THE MAIN LOOP FUNCTION (Runs Forever) ---

void loop() {
  
  Serial.println(F("[BEACON] Broadcasting: 'S' (... )"));
  // Trigger 3 short blinks (dots) to signal the letter 'S'
  triggerSignal(SHORT_BLINK_MS, 3);  
  delay(LETTER_GAP_MS);              // Short pause before moving to the next letter
  
  Serial.println(F("[BEACON] Broadcasting: 'O' (---)"));
  // Trigger 3 long blinks (dashes) to signal the letter 'O'
  triggerSignal(LONG_BLINK_MS, 3);   
  delay(LETTER_GAP_MS);              // Short pause before moving to the next letter
  
  Serial.println(F("[BEACON] Broadcasting: 'S' (... )"));
  // Trigger 3 short blinks (dots) to signal the final letter 'S'
  triggerSignal(SHORT_BLINK_MS, 3);  
  
  Serial.println(F("[STATUS] Sequence complete. Entering cycle rest block."));
  Serial.println(F("--------------------------------------------------"));
  
  // Wait 3 full seconds in total darkness before broadcasting the emergency message again
  delay(CYCLE_DELAY_MS);            
}


// --- STEP 4: CUSTOM MODULAR FUNCTION DEFINITION ---
// This is a custom function. It acts like a mini-program that we can call on demand 
// from our main loop. It accepts two custom input configuration parameters:
// 'duration' (how long to leave the light on) and 'repetitions' (how many times to blink).

void triggerSignal(int duration, int repetitions) {
  
  // A 'for' loop is an automated counter box. 
  // It initializes a counter 'i' at 0. It checks if 'i' is less than our target 'repetitions'.
  // If true, it runs the code inside, adds 1 to 'i' using 'i++', and repeats until finished.
  for (int i = 0; i < repetitions; i++) {
    
    digitalWrite(BEACON_LED, HIGH);  // Energize the pin to turn the LED indicator ON
    delay(duration);                 // Hold the light on for the specified length of time
    
    digitalWrite(BEACON_LED, LOW);   // Cut power to the pin to turn the LED indicator OFF
    delay(INNER_GAP_MS);             // Force a tiny pause so individual blinks don't blur together
  }
}