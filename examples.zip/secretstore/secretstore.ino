/*
  ================================================================================
  PROJECT: EEPROM Persistent Text Vault Utility
  AUTHOR:         G Venkat
  ORGANIZATION:   byteSmart
  WEBSITE:        https://bytesmart.info
  DATE:           July 2026
  VERSION:        1.0.0
  
  COPYRIGHT & LICENSE:
  Copyright (c) 2026 G Venkat. All rights reserved.
  
  TERMS OF USE & COMMERCIAL RESTRICTIONS:
  1. Personal & Educational Use: Free to use, modify, and distribute for 
     non-commercial purposes, provided this complete notice remains intact.
  2. Commercial Use & Extensions: ANY commercial use, sale, or derivative 
     extension of this software is strictly prohibited without prior written 
     permission. For commercial licensing inquiries, please contact the 
     Author and Organization at the email address listed above.
     
  This software is provided "as is", without warranty of any kind.
  ================================================================================
  
  WHAT THIS SIGNATURE PROGRAM DOES:
  This program interacts directly with the Arduino's non-volatile EEPROM memory. 
  Unlike standard RAM which wipes itself clean when power is disconnected, 
  EEPROM acts like a tiny on-board hard drive. This program reads text out of long-
  term storage upon boot, displays it, and allows the user to overwrite that 
  storage sector with a brand new string dynamically.
*/

// --- STEP 1: INCLUDE LIBRARIES ---
// The EEPROM library provides the complex commands needed to speak to the 
// internal physical flash cells inside the microcontroller chip.
#include <EEPROM.h>

// --- STEP 2: GLOBAL SETTINGS (Our Constants) ---
// Defining the maximum capacity of our text container in one central place.
// This makes it extremely easy to scale up the character limit later!
const int MEMORY_MAX_SIZE = 100; 
const int EEPROM_START_ADDRESS = 0; 


// --- STEP 3: THE SETUP FUNCTION (Runs Exactly ONCE) ---

void setup() {
  
  // Initialize Serial pipeline at 115200 baud for ultra-fast, modern performance
  Serial.begin(115200);
  
  // Pause code execution until the user manually launches the Serial Monitor window
  while (!Serial) {
    ; // Spin wheels safely
  }

  // Print our custom styled terminal header menu
  Serial.println(F("\n========================================================="));
  Serial.println(F("       EEPROM PERSISTENT DATA STORAGE TERMINAL           "));
  Serial.println(F("========================================================="));

  // Create a clean, empty character array (a row of slots) to hold our text string
  char secretMessage[MEMORY_MAX_SIZE] = {0};

  // 'EEPROM.get()' goes to a specific address point (0) and reads out exactly 
  // enough bytes to fill up our designated container variable size (100 bytes).
  EEPROM.get(EEPROM_START_ADDRESS, secretMessage);

  // Output whatever phrase was safely stored during the board's last active session
  Serial.println(F("Last saved data found in permanent memory:"));
  Serial.print(F("-> \""));
  Serial.print(secretMessage);
  Serial.println(F("\""));
  Serial.println(F("---------------------------------------------------------"));
  Serial.println(F("Type a new sentence and hit Enter to overwrite memory:"));
  Serial.print(F("Input: "));
}


// --- STEP 4: THE LOOP FUNCTION (Runs Forever) ---

void loop() {
  
  // Check if character bytes are streaming into the serial buffer from the computer
  if (Serial.available() > 0) {
    
    // Read everything typed into the monitor bar until an Enter keystroke ('\n') lands
    String inputString = Serial.readStringUntil('\n');
    
    // '.trim()' strips away trailing carriage returns or hidden whitespace paddings
    inputString.trim(); 

    // Create a local raw character array matching our baseline size profile
    char newSecret[MEMORY_MAX_SIZE] = {0};
    
    // Extract the raw character characters out of the advanced 'String' object 
    // and copy them down into our fixed-size standard array structure.
    inputString.toCharArray(newSecret, MEMORY_MAX_SIZE);

    // 'EEPROM.put()' writes data to the internal flash blocks. 
    // SMART FEATURE: Unlike old 'EEPROM.write()', '.put()' evaluates the current data.
    // If the memory cell already holds that exact letter, it skips writing it.
    // This dramatically extends your microcontroller's life expectancy!
    EEPROM.put(EEPROM_START_ADDRESS, newSecret);

    // Clear our reading variable to prove we are pulling fresh data next
    char verificationBuffer[MEMORY_MAX_SIZE] = {0};
    
    // Read the data back immediately to verify a successful transaction
    EEPROM.get(EEPROM_START_ADDRESS, verificationBuffer);

    // Display confirmation and showcase data permanence
    Serial.println(newSecret); // Echo original input text
    Serial.println(F("\n[SUCCESS] Flash cells updated."));
    Serial.print(F("[CONFIRMED] Stored Data: \""));
    Serial.print(verificationBuffer);
    Serial.println(F("\""));
    Serial.println(F("Status: Safe to completely disconnect power or unplug USB."));
    Serial.println(F("========================================================="));
    
    // Instead of freezing, prompt the user so they can continue typing without resetting!
    Serial.println(F("Type another sentence to overwrite memory again:"));
    Serial.print(F("Input: "));
  }
}